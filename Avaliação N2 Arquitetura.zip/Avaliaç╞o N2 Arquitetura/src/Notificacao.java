interface Notificacao {
    void enviar(String mensagem);
}

